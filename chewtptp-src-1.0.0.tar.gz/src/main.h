#ifndef _MAIN_H_
#define _MAIN_H_

#define MAXLITS 		48	/* Maximum number of literals in a clause */
#define MAXARGS 		48	/* Maximum number of arguments in a literal */

void 	remove_files_and_exit();

#endif 
