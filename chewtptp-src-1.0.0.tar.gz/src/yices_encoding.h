#ifndef YICES_ENCODING_H_
#define YICES_ENCODING_H_

#include "stdio.h"

void assert_term_type();
void term2YicesDatatype(TERM, char*);

#endif
