#ifndef _ENCODE_UTIL_H_
#define _ENCODE_UTIL_H_

#include <string>
#include "stdio.h"
#include "struct.h"

bool get_num(SUB&, int&);
string int2string(int);
int string2number(string);

#endif
