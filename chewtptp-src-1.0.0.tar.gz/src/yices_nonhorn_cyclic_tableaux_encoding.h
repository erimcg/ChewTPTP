#ifndef SMT_NON_HORN_H_
#define SMT_NON_HORN_H_

void yices_non_horn_encoding();

#endif
