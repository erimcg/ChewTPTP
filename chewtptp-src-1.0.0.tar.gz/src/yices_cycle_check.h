#ifndef _DEC_PROC_H_
#define _DEC_PROC_H_

bool found_invalid_cycles();
void push_var_unifiers(TERM, vector<TERM> &, vector<TERM> &);

#endif


